import React, { Component } from 'react';
import {
  Image,
  TouchableOpacity,
  FlatList,
  WebView,
  BackHandler,
  Platform,
  StatusBar,
  Text,
  View,
  StyleSheet,
} from 'react-native';
import { Icon } from 'react-native-elements';
import { Constants } from 'expo';

// You can import from local files
import InfoModal from './components/infoModal';

const dataModel = [
              {
                "app": "facebook",
                "url": "https://facebook.com"
              },
              {
                "app": "twitter",
                "url": "https://twitter.com/login"
              },
              {
                "app": "instagram",
                "url": "https://www.instagram.com/accounts/login/"
              },
              {
                "app": "tumblr",
                "url": "https://www.tumblr.com/login"
              },
              {
                "app": "linkedin",
                "url": "https://www.linkedin.com/uas/login"
              },
              {
                "app": "pinterest",
                "url": "https://www.pinterest.com/login/"
              }];

export default class App extends Component {
  state = {
    isShowModal:false,
    currentAppUrl:'',
    data: dataModel
  };
    
  webView = {
    canGoBack: false,
    ref: null,
  };
  onAndroidBackPress = () => {
    if (this.webView.canGoBack && this.webView.ref) {
      this.webView.ref.goBack();
      return true;
    }
    return false;
  };
  componentWillMount() {
    if (Platform.OS === 'android') {
      BackHandler.addEventListener(
        'hardwareBackPress',
        this.onAndroidBackPress
      );
    }
  }
  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener('hardwareBackPress');
    }
  }
  _onItemPress = (url) => {
    this.setState({currentAppUrl: url});
    //alert(url);
  };
  _onInfoPress = (flag:boolean) => {
    this.setState({isShowModal: flag});
  };

  render() {
    return (
      <View style={styles.container}>
        <InfoModal visibleModal={this.state.isShowModal}></InfoModal>
        <WebView
          source={{ uri: this.state.currentAppUrl }}
          style={styles.webview}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          startInLoadingState={false}
          ref={webView => {
            this.webView.ref = webView;
          }}
          onNavigationStateChange={navState => {
            this.webView.canGoBack = navState.canGoBack;
          }}
        />
        <View style={styles.navBar}>
          <Text style={styles.paragraph} onPress={() => this._onInfoPress(true)}>OneApp</Text>
          <FlatList
            horizontal={true}
            data={this.state.data}
            extraData={this.data}
            keyExtractor={this._keyExtractor}
            renderItem={({ item }) => (
              <View>
                <View style={{padding:3}}>
                  <Icon
                    raised
                    name={item.app}
                    type="font-awesome"
                    color="#f50"
                    onPress={() => this._onItemPress(item.url)}
                  />
                </View>
              </View>
            )}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
    marginTop: StatusBar.currentHeight,
  },
  navBar:{
    flexDirection: 'row'
  },
  paragraph: {
    padding: 3,
    fontSize: 18,
    fontWeight: 'bold',
    textAlignVertical: 'center',
    color: '#34495e',
  },
  webview: {
    flex: 1
  }
});
