import React, {Component} from 'react';
import {Modal, Text, TouchableOpacity, View, StyleSheet, Image } from 'react-native';
import { Card } from 'react-native-elements'; 

export default class InfoModal extends Component {

  constructor(props) {
    super(props);
    this.state = { modalVisible: this.props.visibleModal };
  }

  componentWillReceiveProps(newProps) {
      this.setState({modalVisible: newProps.visibleModal});
  }

  setModalVisible(visible) {
    this.setState({modalVisible: visible});
  }

  render() {    
    return (
      <View style={{}}>
        <Modal
          animationType="slide"
          transparent={false}
          visible={this.state.modalVisible}>
          <TouchableOpacity 
                onPress={() => {
                  this.setModalVisible(!this.state.modalVisible);
                }}>
                <Card title="About">
                  <View style={styles.container}>
                    <Text style={styles.paragraph}>
                      This App can be used based on personal preference.
                      This App was designed keeping user privacy in mind, thus it dosen't request your any permission/access on your device.
                      It is similar to accessing web sites with in the popular social media app. 
                    </Text>
                    <Text style={styles.paragraph}>
                      This App was designed keeping user privacy in mind, thus it dosen't request your any permission/access on your device.
                      
                    </Text>
                    <Text style={styles.paragraph}>
                    </Text>
                    <Text style={styles.paragraph}>
                      It is similar to accessing web sites with in the popular social media app. 
                    </Text>
                  </View>
                </Card>
                <Card title="@Developer">
                  <Text style={styles.paragraph}>touchsenseapps@gmail.com</Text>
                </Card>
                <Card title="X Close">
                </Card>
          </TouchableOpacity>
        </Modal>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  }
});
